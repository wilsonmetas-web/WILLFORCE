import React from 'react';

interface LogoProps {
  variant?: 'horizontal' | 'vertical' | 'icon';
  theme?: 'light' | 'dark' | 'mono';
  className?: string;
  showTagline?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  variant = 'horizontal',
  theme = 'dark',
  className = '',
  showTagline = true,
}) => {
  const colors = {
    darkBlue: '#0A213F',
    lightBlue: '#3175B7',
    gold: '#E6B742',
    wine: '#8E2126',
    white: '#FFFFFF',
    black: '#000000',
  };

  const getThemeColors = () => {
    if (theme === 'mono') {
      return {
        iconGold: 'currentColor',
        iconBlue: 'currentColor',
        iconOrange: 'currentColor',
        text: 'currentColor',
        tagline: 'currentColor',
      };
    }
    if (theme === 'light') {
      return {
        iconGold: colors.gold,
        iconBlue: colors.lightBlue,
        iconOrange: '#F58220', // Using an orange for the triangle as seen in image
        text: colors.darkBlue,
        tagline: colors.darkBlue,
      };
    }
    // Default dark theme (light text on dark background)
    return {
      iconGold: colors.gold,
      iconBlue: colors.lightBlue,
      iconOrange: '#F58220',
      text: colors.white,
      tagline: colors.white,
    };
  };

  const themeColors = getThemeColors();

  const Icon = () => (
    <svg
      viewBox="0 0 140 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-full w-auto"
    >
      {/* Stroke 1: Gold (\) */}
      <path
        d="M10 15L45 85H60L25 15H10Z"
        fill={themeColors.iconGold}
      />
      {/* Stroke 2: Blue (/) */}
      <path
        d="M40 85L70 15H85L55 85H40Z"
        fill={themeColors.iconBlue}
      />
      {/* Stroke 3: Blue (\) */}
      <path
        d="M65 15L95 85H110L80 15H65Z"
        fill={themeColors.iconBlue}
      />
      {/* Stroke 4: Blue (/) */}
      <path
        d="M90 85L120 15H135L105 85H90Z"
        fill={themeColors.iconBlue}
      />
      {/* Bottom Orange Triangle at the first valley */}
      <path
        d="M45 85L52.5 70L60 85H45Z"
        fill={themeColors.iconOrange}
      />
    </svg>
  );

  if (variant === 'icon') {
    return (
      <div className={`h-12 ${className}`}>
        <Icon />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-6 ${variant === 'vertical' ? 'flex-col text-center' : 'flex-row'} ${className}`}>
      <div className="h-16 shrink-0">
        <Icon />
      </div>
      <div className="flex flex-col justify-center">
        <h1 
          className="font-bold tracking-wider leading-none"
          style={{ 
            color: themeColors.text,
            fontSize: variant === 'vertical' ? '2.5rem' : '3.5rem'
          }}
        >
          WILLFORCE
        </h1>
        {showTagline && (
          <p 
            className="mt-2 text-[0.65rem] font-medium tracking-[0.2em] uppercase opacity-90"
            style={{ color: themeColors.tagline }}
          >
            FORTALECENDO PESSOAS, TRANSFORMANDO ORGANIZAÇÕES
          </p>
        )}
      </div>
    </div>
  );
};
