import React from 'react';
import { motion } from 'motion/react';
import { Logo } from './components/Logo';
import { Check, X, Copy, Download, Palette, Type, Layout, ShieldAlert } from 'lucide-react';

export default function App() {
  const colors = [
    { name: 'Azul Escuro', hex: '#0A213F', desc: 'Cor principal para fundos e contraste.' },
    { name: 'Azul Claro', hex: '#3175B7', desc: 'Cor de destaque para elementos da marca.' },
    { name: 'Dourado', hex: '#E6B742', desc: 'Cor de prestígio e iluminação.' },
    { name: 'Vinho', hex: '#8E2126', desc: 'Cor complementar para detalhes.' },
  ];

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // Simple feedback could be added here
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A]">
      {/* Header */}
      <header className="bg-brand-dark-blue py-12 px-6 text-white overflow-hidden relative">
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Logo variant="horizontal" theme="dark" showTagline={false} className="mb-4" />
            <h1 className="text-4xl font-bold mt-8">Manual de Identidade Visual</h1>
            <p className="text-blue-200 mt-2 text-lg max-w-2xl">
              Diretrizes oficiais para a aplicação da marca Willforce, garantindo consistência e integridade em todos os pontos de contato.
            </p>
          </motion.div>
        </div>
        {/* Abstract background element */}
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none">
          <Logo variant="icon" theme="mono" className="w-full h-full scale-150 rotate-12" />
        </div>
      </header>

      <main className="max-w-6xl mx-auto py-16 px-6 space-y-24">
        
        {/* 1. Paleta de Cores */}
        <section id="colors">
          <div className="flex items-center gap-3 mb-8">
            <Palette className="text-brand-light-blue" size={28} />
            <h2 className="text-3xl font-bold">1. Paleta de Cores Oficial</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {colors.map((color, idx) => (
              <motion.div
                key={color.hex}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 group"
              >
                <div 
                  className="h-32 w-full rounded-xl mb-4 relative overflow-hidden cursor-pointer"
                  style={{ backgroundColor: color.hex }}
                  onClick={() => copyToClipboard(color.hex)}
                >
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20">
                    <Copy className="text-white" size={24} />
                  </div>
                </div>
                <h3 className="font-bold text-lg">{color.name}</h3>
                <p className="text-gray-500 text-sm font-mono mt-1 uppercase">{color.hex}</p>
                <p className="text-gray-600 text-xs mt-3 leading-relaxed">{color.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* 2. Tipografia */}
        <section id="typography">
          <div className="flex items-center gap-3 mb-8">
            <Type className="text-brand-light-blue" size={28} />
            <h2 className="text-3xl font-bold">2. Tipografia Recomendada</h2>
          </div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-brand-light-blue font-semibold mb-4 uppercase tracking-widest text-sm">Fonte Primária</h3>
              <p className="text-6xl font-bold mb-2">Montserrat</p>
              <p className="text-gray-600 mb-8">
                Utilizada para títulos e elementos de destaque. Transmite modernidade, clareza e força.
              </p>
              <div className="space-y-4">
                <p className="text-4xl font-bold">Aa Bb Cc Dd Ee Ff</p>
                <p className="text-4xl font-medium">Aa Bb Cc Dd Ee Ff</p>
                <p className="text-4xl font-normal">Aa Bb Cc Dd Ee Ff</p>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-2xl">
              <h3 className="text-gray-500 font-semibold mb-6 uppercase tracking-widest text-xs">Exemplo de Aplicação</h3>
              <div className="space-y-6">
                <div>
                  <p className="text-xs text-brand-light-blue font-bold uppercase tracking-widest mb-1">Título de Seção</p>
                  <p className="text-2xl font-bold leading-tight">A força que transforma sua organização.</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Corpo de Texto</p>
                  <p className="text-gray-600 leading-relaxed">
                    A Willforce acredita no potencial humano como motor principal de qualquer mudança organizacional. Nossas soluções são desenhadas para fortalecer pessoas.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Versões da Logomarca */}
        <section id="versions">
          <div className="flex items-center gap-3 mb-8">
            <Layout className="text-brand-light-blue" size={28} />
            <h2 className="text-3xl font-bold">3. Versões da Logomarca</h2>
          </div>
          
          <div className="space-y-12">
            {/* Dark Theme Showcase */}
            <div className="bg-brand-dark-blue p-12 rounded-3xl overflow-hidden relative">
              <p className="text-white/40 text-xs font-bold uppercase tracking-[0.3em] mb-12">Versão sobre fundo escuro (Principal)</p>
              <div className="flex flex-col md:flex-row items-center justify-around gap-12">
                <Logo variant="horizontal" theme="dark" />
                <div className="h-px w-24 bg-white/10 hidden md:block" />
                <Logo variant="vertical" theme="dark" />
              </div>
            </div>

            {/* Light Theme Showcase */}
            <div className="bg-white p-12 rounded-3xl border border-gray-100">
              <p className="text-gray-400 text-xs font-bold uppercase tracking-[0.3em] mb-12">Versão sobre fundo claro</p>
              <div className="flex flex-col md:flex-row items-center justify-around gap-12">
                <Logo variant="horizontal" theme="light" />
                <div className="h-px w-24 bg-gray-100 hidden md:block" />
                <Logo variant="vertical" theme="light" />
              </div>
            </div>

            {/* Mono Theme Showcase */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-brand-light-blue p-12 rounded-3xl text-white">
                <p className="text-white/40 text-xs font-bold uppercase tracking-[0.3em] mb-12">Versão Monocromática (Branco)</p>
                <Logo variant="horizontal" theme="mono" />
              </div>
              <div className="bg-gray-200 p-12 rounded-3xl text-black">
                <p className="text-black/20 text-xs font-bold uppercase tracking-[0.3em] mb-12">Versão Monocromática (Preto)</p>
                <Logo variant="horizontal" theme="mono" />
              </div>
            </div>
          </div>
        </section>

        {/* 4. Regras de Aplicação */}
        <section id="rules">
          <div className="flex items-center gap-3 mb-8">
            <ShieldAlert className="text-brand-light-blue" size={28} />
            <h2 className="text-3xl font-bold">4. Regras de Aplicação</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-green-50 p-8 rounded-3xl border border-green-100">
              <div className="flex items-center gap-2 text-green-700 font-bold mb-6">
                <Check size={20} />
                <h3>Uso Correto</h3>
              </div>
              <ul className="space-y-4 text-green-800/80 text-sm">
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0" />
                  Sempre manter margens mínimas ao redor da marca.
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0" />
                  Usar apenas versões fornecidas oficialmente.
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-1.5 shrink-0" />
                  Manter a proporção original em qualquer redimensionamento.
                </li>
              </ul>
            </div>

            <div className="bg-red-50 p-8 rounded-3xl border border-red-100">
              <div className="flex items-center gap-2 text-red-700 font-bold mb-6">
                <X size={20} />
                <h3>Uso Incorreto</h3>
              </div>
              <ul className="space-y-4 text-red-800/80 text-sm">
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                  Não aplique sombras, contornos ou gradientes não oficiais.
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                  Não distorça, estique ou incline o logotipo.
                </li>
                <li className="flex gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
                  Nunca use a logo sobre fundos conflitantes ou multicoloridos.
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* 5. Downloads */}
        <section id="downloads" className="pb-24">
          <div className="bg-brand-dark-blue rounded-[3rem] p-12 text-white text-center relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-3xl font-bold mb-4">Pronto para usar?</h2>
              <p className="text-blue-200 mb-8 max-w-lg mx-auto">
                Baixe o pacote completo de ativos da marca em alta resolução para seus projetos.
              </p>
              <button className="bg-brand-gold hover:bg-yellow-500 text-brand-dark-blue font-bold py-4 px-10 rounded-full transition-all transform hover:scale-105 flex items-center gap-2 mx-auto">
                <Download size={20} />
                Baixar Brand Kit (.ZIP)
              </button>
            </div>
            {/* Decorative circles */}
            <div className="absolute -bottom-24 -left-24 w-64 h-64 rounded-full bg-brand-light-blue/20 blur-3xl" />
            <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-brand-gold/10 blur-3xl" />
          </div>
        </section>
      </main>

      <footer className="bg-white border-t border-gray-100 py-12 px-6 text-center">
        <Logo variant="icon" theme="light" className="mx-auto mb-6 opacity-50" />
        <p className="text-gray-400 text-sm">
          &copy; {new Date().getFullYear()} Willforce. Todos os direitos reservados.
        </p>
      </footer>
    </div>
  );
}

